# Qualtrics document generator

Convert a Qualtrics `.qsf` survey export into an editable Word document for collecting responses on paper.

The converter preserves survey wording and supported rich text formatting, creates editable response tables, and adapts pagination for print. Matrix questions use statement rows, equal-width scale columns, and optional rotated headers. Online page breaks are ignored. Block headings and fresh pages for later blocks are independent options, both off by default.

Dropdowns now retain short lists and recognized ordered lists (such as age, height, years of service, and military rank grades) as multiple-choice response tables. Long lists of short labels can use up to three columns, read down each column in survey order. Unordered dropdowns with 50 or more choices become write-ins by default. Configure the threshold, column limit, or `responses.dropdown_mode` (`auto`, `choices`, or `write_in`), including per-question overrides.

## Run locally

Requires Python 3.8 or newer.

[Download the current code and configuration](downloads/Qualtrics-document-generator-dropdown-options-20261028.zip).

```bash
pip install -r requirements.txt
python qsf_to_paper.py your-survey.qsf
```

This creates `your-survey-paper.docx` beside the input. Open it in Word to review, adjust, print, or export to PDF.

To choose an output location:

```bash
python qsf_to_paper.py your-survey.qsf -o paper-survey.docx
```

## Configure formatting

All defaults are built into the Python code. The optional `config.json` beside the script supplies your general preferences. A separate survey config can override those preferences and individual questions by their stable QID.

```bash
python qsf_to_paper.py your-survey.qsf --survey-config your-survey_config.json
python qsf_to_paper.py your-survey.qsf --response-font-size 10 --bold-questions
python qsf_to_paper.py your-survey.qsf --set matrix.row_bottom_border.enabled=true
python qsf_to_paper.py your-survey.qsf --show-block-names --new-page-per-block
```

Settings apply in this order: built-in defaults, main config, survey config, general CLI options, then per-question overrides. Missing config files do not prevent conversion. See [the configuration guide](docs/configuration.md) for all settings and examples.

```bash
python qsf_to_paper.py --help
python qsf_to_paper.py your-survey.qsf --list-questions
```

## Included examples

- Latest response-layout update: [source ZIP](downloads/Qualtrics-document-generator-4b6916e.zip), [MRE Word](examples/FY27_MRE_IOTE-paper-logic-4b6916e.docx), and [MRE PDF](examples/FY27_MRE_IOTE-paper-logic-4b6916e.pdf). These versioned downloads include vertical Yes/No choices, more form writing space where the page permits, banded lists above 10 choices, and 0.5-inch multiple-choice indentation.
- [Example survey QSF](examples/Example_survey.qsf)
- [Example Word document](examples/Example_survey-paper.docx) and [PDF](examples/Example_survey-paper.pdf), using the default print layout
- [Example with respondent logic in Word](examples/Example_survey-paper-logic.docx) and [PDF](examples/Example_survey-paper-logic.pdf), with the analyzer's years-of-service skip direction added to a separate generated copy; [analysis report](examples/Example_survey-logic.json)
- [Survey-specific configuration](examples/Example_survey_config.json), demonstrating survey numbering, bold prompts, and a QID-specific matrix border style
- [Qualtrics product survey demo](examples/Demo_product_survey.qsf)
- [Real fuel handler survey](examples/Extreme_Cold_Weather_Fuel_Handler_Handwear_Survey.qsf), with [Word](examples/Extreme_Cold_Weather_Fuel_Handler_Handwear_Survey-paper-logic.docx), [PDF](examples/Extreme_Cold_Weather_Fuel_Handler_Handwear_Survey-paper-logic.pdf), [survey config](examples/Extreme_Cold_Weather_Fuel_Handler_Handwear_Survey_config.json), and [routing/layout evaluation](docs/handwear-evaluation.md)
- [FY27 MRE survey](examples/FY27_MRE_IOTE.qsf), with default-settings [Word](examples/FY27_MRE_IOTE-paper-logic.docx), [PDF](examples/FY27_MRE_IOTE-paper-logic.pdf), [logic report](examples/FY27_MRE_IOTE-logic.json), and [evaluation of layout and unsupported logic](docs/mre-evaluation.md)
- [Manually revised layout reference](examples/references/Example_survey-paper_revised.docx), retained as a formatting reference

Generate examples into an ignored local output directory:

```bash
mkdir output
python qsf_to_paper.py examples/Example_survey.qsf -o output/example.docx
python qsf_to_paper.py examples/Example_survey.qsf --survey-config examples/Example_survey_config.json -o output/example-custom.docx
python qsf_to_paper.py examples/Demo_product_survey.qsf -o output/demo.docx
```

The supplied Word/PDF example shows the reviewed default layout. The survey-specific configuration changes its appearance when applied.

## Validation and scope

Run the configuration regression checks from the repository root:

```bash
python tests/test_configuration.py
python tests/test_config_layers.py
python tests/test_logic.py
python tests/test_logic_document.py
python tests/test_response_layout.py
python tests/test_block_sections.py
python tests/test_dropdown_layout.py
```

The formatter preserves all non-trash questions it finds, including those absent from survey flow. Question types without a full paper equivalent produce a console warning for manual review. Very large matrices may span pages or become multiple column panels to retain their content.

The Word converter currently omits logic. A separate [respondent logic prototype](docs/logic.md) proposes skip directions for questions and “Answer this section only if…” directions for conditional blocks, without changing the converter:

```bash
python qsf_logic.py your-survey.qsf -o instructions.json
python qsf_logic_to_paper.py your-survey.qsf --report instructions.json
```

The optional adapter inserts respondent instructions into a separate generated Word copy; the original converter is unchanged. These scripts generate Word documents; the included PDFs are exported examples.
